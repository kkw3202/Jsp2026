<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" import="java.util.*"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>EL Login</title>
<style type="text/css">
	.container{
		width: 600px;
		margin: 20px auto;
	}
</style>
</head>
<body>
	<div class="container">
		<h2>로그인 페이지</h2>
		<form action="ELloginProc.jsp" method="post">
			<table width="600" border="1">
				<tr height="60">
					<td align="center" width="150">아이디</td>
					<td align="center" width="350">
						<input type="text" name="id"/>
					</td>
				</tr>
				<tr height="60">
					<td align="center" width="150">비밀번호</td>
					<td align="center" width="350">
						<input type="password" name="pass"/>
					</td>
				</tr>		
				<tr height="60">
					<td colspan="2" align="center" width="150">
						<input type="submit" value="전송"/>
					</td>
				</tr>		
			</table>
		</form>
	
	</div>
</body>
</html>