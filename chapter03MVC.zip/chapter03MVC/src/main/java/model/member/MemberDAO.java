package model.member;
import java.sql.*;
import java.util.*;

import DBPKG.Util;

public class MemberDAO {
	// �������� �����
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	String sql ="";
	//---- ���� sql�� �ۼ� �޼ҵ��� ����
	
	
	// id�� �����ϴ� �޼ҵ� �ۼ�. // �޼ҵ�� : getId()
	public String getId(String id) {
		String chkid="";
		
		try {
			con = Util.getConnection();
			
			sql = "select id from member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				chkid = id;
				// chkid = rs.getString(1);
				// chkid = rs.getString("id"); 
				// 3���� ���� ���� ��Ȳ������ ��� ����!
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
		return chkid;
	}
	public String getPass(String id) {
		String chkpass="";
		
		try {
			con = Util.getConnection();
			
			sql = "select pass from member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				chkpass = rs.getString("pass");
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
		return chkpass;
	}
	// --------------- 
	// �� ����� �����͸� DB�� �����ϴ� �޼ҵ�
	public void insertMember(MemberDTO mdto) {
		try {
			con = Util.getConnection();
			
			String sql = "insert into member values (?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mdto.getId());
			pstmt.setString(2, mdto.getPass());
			pstmt.setString(3, mdto.getEmail());
			pstmt.setString(4, mdto.getTel());
			pstmt.setString(5, mdto.getHobby());
			pstmt.setString(6, mdto.getJob());
			pstmt.setString(7, mdto.getAge());
			pstmt.setString(8, mdto.getInfo());
			
			int result = pstmt.executeUpdate();
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
	}
	//------------------
	public ArrayList<MemberDTO> getAllMember() {
		ArrayList<MemberDTO> m = new ArrayList<MemberDTO>();
		
		try {
			con = Util.getConnection();
			
			String sql = "select * from member";
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				MemberDTO mdto = new MemberDTO();
				
				mdto.setId(rs.getString(1));
				mdto.setPass(rs.getString(2));
				mdto.setEmail(rs.getString(3));
				mdto.setTel(rs.getString(4));
				mdto.setHobby(rs.getString(5));
				mdto.setJob(rs.getString(6));
				mdto.setAge(rs.getString(7));
				mdto.setInfo(rs.getString(8));
				
				// ArrayList �� ���� ���
				m.add(mdto);
			}
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
		// ���� �ۼ�
		return m;
	}
	//------------------ 2026-10-28 db ���� ������Ʈ
	// �޼ҵ� �̸� : loginCheck()
	
	public boolean loginCheck(String id, String pass) {
		
		try {
			con = Util.getConnection();
			
			String sql = "select pass from member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				if(rs.getString(1).equals(pass)) return true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			}catch(Exception e) {e.printStackTrace();}
		}
		
		return false;
	}
	//------------------ 2026-10-28 db ���� ������Ʈ
	// �̸��� �Ǵ� ���̵�� ȸ������� �˻��ϴ� �޼ҵ�
	// �޼ҵ� �̸� : searchMemberList()
	
	public ArrayList<MemberDTO> getSearchMember(String searchType, String keyword) {
		ArrayList<MemberDTO> m = new ArrayList<MemberDTO>();
		
		try {
			con = Util.getConnection();
			
			String sql = "select * from member where " + searchType + " like '%"+ keyword +"%'";
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				MemberDTO mdto = new MemberDTO();
				mdto.setId(rs.getString(1));
				mdto.setPass(rs.getString(2));
				mdto.setEmail(rs.getString(3));
				mdto.setTel(rs.getString(4));
				mdto.setHobby(rs.getString(5));
				mdto.setJob(rs.getString(6));
				mdto.setAge(rs.getString(7));
				mdto.setInfo(rs.getString(8));
				
				m.add(mdto);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
		// ���� �ۼ�
		return m;
	}
	//------------------ 2026-10-28 db ���� ������Ʈ
	// ȸ�� �� ���� ��� ������ �����ϴ� �޼ҵ�
	public MemberDTO getMemberDetail(String id) {
		MemberDTO mdto = new MemberDTO();
		try {
			con = Util.getConnection();
			
			String sql = "select * from member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				mdto.setId(rs.getString(1));
				mdto.setPass(rs.getString(2));
				mdto.setEmail(rs.getString(3));
				mdto.setTel(rs.getString(4));
				mdto.setHobby(rs.getString(5));
				mdto.setJob(rs.getString(6));
				mdto.setAge(rs.getString(7));
				mdto.setInfo(rs.getString(8));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
		return mdto;
	}
	//------------------ 2026-10-28 db ���� ������Ʈ
	// ȸ�� �� ���� ��� ������ ������Ʈ �ϴ� �޼ҵ�
	public int setUpdateMember(MemberDTO mdto) {
		int result = 0;
		
		try {
			con = Util.getConnection();
			
			String sql = "update member set pass=?, email=?, tel=?, hobby=?, job=?, age=?, info=? where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mdto.getPass());
			pstmt.setString(2, mdto.getEmail());
			pstmt.setString(3, mdto.getTel());
			pstmt.setString(4, mdto.getHobby());
			pstmt.setString(5, mdto.getJob());
			pstmt.setString(6, mdto.getAge());
			pstmt.setString(7, mdto.getInfo());
			pstmt.setString(8, mdto.getId());
			
			result = pstmt.executeUpdate();
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(con != null) con.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			}catch (Exception e) {e.printStackTrace();}
		}
		return result;
	}
	
	
}
